function toggleDropdown() {
    var dropdown = document.querySelector('.langDropdown');
    dropdown.classList.toggle('active');
}

function selectLanguage(lang) {
    // Seçilen dili kullanmak için yapılacak işlemleri burada gerçekleştirin
}